<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name ="viewport" content="width=device-width, initial-scale=1.0">
    <title>Usuário Novo</title>
</head>
<body>
    <h1>Nova Tarefa</h1>
    <form action="index.php?action=createtask" method="post">
        <label for="tarefa">Tarefa:</label>
        <input type="text" id="tarefa" name="tarefa" required>
        <br>
        <label for="prazo">Prazo:</label>
        <input type="prazo" id="prazo" name="prazo" required>
        <br>
        <input type="submit" value="Create">
    </form>
    <a href="index.php"> Voltar a tarefas </a>
</body>
</html>
